import React, { useState, useEffect } from "react";
import { 
  Terminal, 
  Cpu, 
  Code2, 
  Zap, 
  Moon, 
  HelpCircle, 
  FolderGit2, 
  Activity, 
  CloudOff, 
  CloudLightning,
  Undo2,
  RefreshCw
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Dashboard from "./components/Dashboard";
import ProjectExplorer from "./components/ProjectExplorer";
import AiderChat from "./components/AiderChat";
import AutomationControl from "./components/AutomationControl";
import ModelSelector from "./components/ModelSelector";
import { 
  VirtualProject, 
  AiderTask, 
  SystemTelemetry, 
  LogMessage, 
  ModelConfig,
  TelegramConfig,
  UITheme
} from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'explorer' | 'aider' | 'automation' | 'models'>('dashboard');
  const [projects, setProjects] = useState<Record<string, VirtualProject>>({});
  const [activeProjectId, setActiveProjectId] = useState<string>("project-1");
  const [tasks, setTasks] = useState<AiderTask[]>([]);
  const [logs, setLogs] = useState<LogMessage[]>([]);
  const [telemetry, setTelemetry] = useState<SystemTelemetry>({
    cpuUsage: 14,
    ramUsage: 31,
    activeTasks: 0,
    tokensUsed: 0,
    tokensLimit: 250000,
    apiCost: 0,
    offlineFallbackActive: false,
    isNightMode: false,
    networkSpeed: 142,
    ramWarningTriggered: false,
    performanceCritical: false,
    leakDetectionActive: true
  });
  const [modelConfigs, setModelConfigs] = useState<ModelConfig[]>([]);
  const [selectedModelId, setSelectedModelId] = useState<string>("gemini-3.5-flash");
  const [isNightModeAutomationRunning, setIsNightModeAutomationRunning] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // New states
  const [lang, setLang] = useState<'en' | 'ru'>(() => {
    const saved = localStorage.getItem("aider_cockpit_lang");
    return (saved === "ru" || saved === "en") ? saved : "en";
  });

  const handleToggleLang = () => {
    const nextLang = lang === 'en' ? 'ru' : 'en';
    setLang(nextLang);
    localStorage.setItem("aider_cockpit_lang", nextLang);
  };

  const [currentTheme, setCurrentTheme] = useState<UITheme>('midnight');
  const [memoryPoolEnabled, setMemoryPoolEnabled] = useState<boolean>(false);
  const [rustFfiApplied, setRustFfiApplied] = useState<boolean>(false);
  const [telegramConfig, setTelegramConfig] = useState<TelegramConfig>({
    botToken: "",
    chatId: "",
    enabled: false,
    status: 'disconnected'
  });

  // Synchronize state from Express server backend
  const fetchState = async () => {
    try {
      const response = await fetch("/api/state");
      const data = await response.json();
      setProjects(data.projects);
      setActiveProjectId(data.activeProjectId);
      setTasks(data.tasks);
      setLogs(data.logs);
      setTelemetry(data.telemetry);
      setModelConfigs(data.modelConfigs);
      setSelectedModelId(data.selectedModelId);
      setIsNightModeAutomationRunning(data.isNightModeAutomationRunning);
      
      // Sync new backend attributes
      if (data.currentTheme) setCurrentTheme(data.currentTheme);
      if (data.telegramConfig) setTelegramConfig(data.telegramConfig);
      setMemoryPoolEnabled(!!data.memoryPoolEnabled);
      setRustFfiApplied(!!data.rustFfiApplied);

      setIsLoading(false);
    } catch (err) {
      console.error("Failed to load server state:", err);
    }
  };

  useEffect(() => {
    fetchState();
    // Continuous polling at 1.5s intervals for ultra-responsive metrics and background Aider workers
    const pollInterval = setInterval(fetchState, 1500);
    return () => clearInterval(pollInterval);
  }, []);

  const handleSelectTheme = async (theme: UITheme) => {
    try {
      const response = await fetch("/api/theme/select", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme })
      });
      const data = await response.json();
      if (data.success) {
        setCurrentTheme(theme);
        fetchState();
      }
    } catch (err) {
      console.error("Failed to swap UI theme:", err);
    }
  };

  const handleUpdateTelegramConfig = async (token: string, chat: string, enabled: boolean) => {
    try {
      const response = await fetch("/api/telegram/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ botToken: token, chatId: chat, enabled })
      });
      const data = await response.json();
      if (data.success) {
        fetchState();
      }
    } catch (err) {
      console.error("Failed to update Telegram Bot config:", err);
    }
  };

  const handleTestTelegram = async () => {
    try {
      const response = await fetch("/api/telegram/test", {
        method: "POST"
      });
      await response.json();
      fetchState();
    } catch (err) {
      console.error("Failed to dispatch Telegram test:", err);
    }
  };

  const handleToggleMemoryPool = async () => {
    try {
      const response = await fetch("/api/project/memory-pool", {
        method: "POST"
      });
      if (response.ok) fetchState();
    } catch (err) {
      console.error("Failed to toggle object pools:", err);
    }
  };

  const handleToggleRustFfi = async () => {
    try {
      const response = await fetch("/api/project/rust-ffi", {
        method: "POST"
      });
      if (response.ok) fetchState();
    } catch (err) {
      console.error("Failed to toggle Rust FFI:", err);
    }
  };

  const handleSelectProject = async (projectId: string) => {
    try {
      const response = await fetch("/api/project/select", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId })
      });
      const data = await response.json();
      if (data.success) {
        setActiveProjectId(projectId);
        fetchState();
      }
    } catch (err) {
      console.error("Failed to change active workspace:", err);
    }
  };

  const handleFileUpdate = async (filePath: string, content: string) => {
    try {
      const response = await fetch("/api/file/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath, content })
      });
      const data = await response.json();
      if (data.success) {
        fetchState();
      }
    } catch (err) {
      console.error("Failed to save file edits:", err);
    }
  };

  const handleTaskCreate = async (prompt: string) => {
    try {
      const response = await fetch("/api/task/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, modelId: selectedModelId })
      });
      const data = await response.json();
      if (data.success) {
        fetchState();
        setActiveTab('aider'); // automatically open aider pipeline tree to inspect task execution
      }
    } catch (err) {
      console.error("Failed to enqueue Aider coding task:", err);
    }
  };

  const handleRunTests = async () => {
    try {
      const response = await fetch("/api/project/run-tests", {
        method: "POST"
      });
      const data = await response.json();
      if (data.success) {
        fetchState();
      }
    } catch (err) {
      console.error("Failed to execute unit test suite:", err);
    }
  };

  const handleToggleNightMode = async () => {
    try {
      const response = await fetch("/api/automation/toggle", {
        method: "POST"
      });
      const data = await response.json();
      if (data.success) {
        setIsNightModeAutomationRunning(data.isNightModeAutomationRunning);
        fetchState();
      }
    } catch (err) {
      console.error("Failed to toggle automation loops:", err);
    }
  };

  const handleSelectModel = async (modelId: string) => {
    try {
      const response = await fetch("/api/model/select", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId })
      });
      const data = await response.json();
      if (data.success) {
        setSelectedModelId(modelId);
        fetchState();
      }
    } catch (err) {
      console.error("Failed to swap active AI engine:", err);
    }
  };

  const handleResetWorkspace = async () => {
    if (!confirm("Are you sure you want to revert the entire virtual workspace back to its original bug-ridden state?")) return;
    try {
      const response = await fetch("/api/project/reset", {
        method: "POST"
      });
      const data = await response.json();
      if (data.success) {
        fetchState();
      }
    } catch (err) {
      console.error("Failed to reset virtual workspace:", err);
    }
  };

  const getThemeClasses = () => {
    switch (currentTheme) {
      case 'cyber':
        return {
          bg: "bg-[#040905]",
          text: "text-emerald-100",
          accentColor: "text-emerald-400",
          borderAccent: "border-emerald-900/40",
          bgAccent: "bg-emerald-950/20",
          glow: "shadow-[0_0_15px_rgba(16,185,129,0.15)]",
          btnActive: "bg-emerald-950/20 text-emerald-400 border-emerald-900/40 shadow-[0_0_15px_rgba(16,185,129,0.1)]",
          badgeAccent: "bg-emerald-950/50 text-emerald-400 border-emerald-900/40",
          selection: "selection:bg-emerald-900/40 selection:text-emerald-200"
        };
      case 'rose':
        return {
          bg: "bg-[#0b0612]",
          text: "text-rose-100",
          accentColor: "text-rose-400",
          borderAccent: "border-rose-900/40",
          bgAccent: "bg-rose-950/20",
          glow: "shadow-[0_0_15px_rgba(236,72,153,0.15)]",
          btnActive: "bg-rose-950/20 text-rose-400 border-rose-900/40 shadow-[0_0_15px_rgba(236,72,153,0.1)]",
          badgeAccent: "bg-rose-950/50 text-rose-400 border-rose-900/40",
          selection: "selection:bg-rose-900/40 selection:text-rose-200"
        };
      case 'rust_perf':
        return {
          bg: "bg-[#0f0a07]",
          text: "text-orange-100",
          accentColor: "text-orange-400",
          borderAccent: "border-orange-900/40",
          bgAccent: "bg-orange-950/20",
          glow: "shadow-[0_0_15px_rgba(249,115,22,0.15)]",
          btnActive: "bg-orange-950/20 text-orange-400 border-orange-900/40 shadow-[0_0_15px_rgba(249,115,22,0.1)]",
          badgeAccent: "bg-orange-950/50 text-orange-400 border-orange-900/40",
          selection: "selection:bg-orange-950/40 selection:text-orange-200"
        };
      default:
        return {
          bg: "bg-slate-950",
          text: "text-slate-100",
          accentColor: "text-cyan-400",
          borderAccent: "border-cyan-900/40",
          bgAccent: "bg-cyan-950/20",
          glow: "shadow-[0_0_15px_rgba(34,211,238,0.15)]",
          btnActive: "bg-cyan-950/20 text-cyan-400 border-cyan-900/40 shadow-[0_0_15px_rgba(6,182,212,0.1)]",
          badgeAccent: "bg-cyan-950/50 text-cyan-400 border-cyan-900/40",
          selection: "selection:bg-cyan-900/40 selection:text-cyan-200"
        };
    }
  };

  const themeCls = getThemeClasses();
  const activeProject = projects[activeProjectId];

  if (isLoading || !activeProject) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center space-y-4 font-mono text-xs select-none">
        <div className="relative flex items-center justify-center">
          <div className="w-12 h-12 rounded-full border-2 border-cyan-950 border-t-cyan-400 animate-spin" />
          <Terminal className="w-5 h-5 text-cyan-400 absolute animate-pulse" />
        </div>
        <p className="text-cyan-400 animate-pulse uppercase tracking-widest font-semibold text-center px-4">
          {lang === 'ru' 
            ? "Запуск изолированных контейнеров и мостов VCS..." 
            : "Spawning Sandboxed Containers & VCS Bridges..."}
        </p>
        <p className="text-slate-600 text-[10px] text-center px-4 max-w-md">
          {lang === 'ru'
            ? "Инициализация виртуальной рабочей области, загрузка средств выполнения тестов и проверка локальных точек Ollama."
            : "Initializing virtual workspace, loading test runners & local Ollama endpoint checkers."}
        </p>
      </div>
    );
  }

  const navItems = [
    { id: 'dashboard', label: lang === 'ru' ? 'Панель мониторинга' : 'Monitor Dashboard', icon: <Activity className="w-4 h-4" /> },
    { id: 'explorer', label: lang === 'ru' ? 'Проводник и тесты' : 'File Explorer & Tests', icon: <Code2 className="w-4 h-4" /> },
    { id: 'aider', label: lang === 'ru' ? 'Задачи Aider' : 'Aider Task Pipeline', icon: <Terminal className="w-4 h-4" /> },
    { id: 'automation', label: lang === 'ru' ? 'Ночная автоматизация' : 'Night Automation', icon: <Moon className="w-4 h-4" /> },
    { id: 'models', label: lang === 'ru' ? 'Настройка моделей' : 'Model Configuration', icon: <Cpu className="w-4 h-4" /> }
  ] as const;

  return (
    <div className={`min-h-screen ${themeCls.bg} ${themeCls.text} flex flex-col antialiased ${themeCls.selection}`}>
      
      {/* Top Header Cockpit Console */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur sticky top-0 z-40 px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        
        {/* Title, logo, status pill */}
        <div className="flex items-center gap-3">
          <div className={`p-2 ${themeCls.bgAccent} border ${themeCls.borderAccent} rounded-lg ${themeCls.glow}`}>
            <Terminal className={`w-5 h-5 ${themeCls.accentColor} animate-pulse`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold tracking-wider font-mono text-slate-200">
                {lang === 'ru' ? "ПАНЕЛЬ УПРАВЛЕНИЯ AIDER" : "AIDER COCKPIT GUI"}
              </h1>
              <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded ${themeCls.badgeAccent} font-mono tracking-widest uppercase`}>
                v2.8-beta
              </span>
            </div>
            
            <div className="flex flex-wrap items-center gap-3 mt-1 text-[10px] text-slate-500 font-mono">
              <span className="flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${telemetry.offlineFallbackActive ? "bg-amber-500" : "bg-emerald-500 animate-pulse"}`} />
                {telemetry.offlineFallbackActive 
                  ? (lang === 'ru' ? "РЕЖИМ ЛОКАЛЬНОГО АВТОНОМНОГО РЕЗЕРВА" : "LOCAL OFFLINE FALLBACK MODE") 
                  : (lang === 'ru' ? "ОНЛАЙН-МОСТ GEMINI API" : "GEMINI API ONLINE BRIDGE")}
              </span>
              
              {isNightModeAutomationRunning && (
                <span className="flex items-center gap-1 text-indigo-400 font-semibold uppercase animate-pulse">
                  <Moon className="w-3 h-3" /> {lang === 'ru' ? "Ночной режим активен" : "Night Mode Loop Active"}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Workspace select dropdown & actions */}
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-[10px] uppercase font-mono text-slate-500 font-bold hidden md:inline">
              {lang === 'ru' ? "Пространство:" : "Workspace:"}
            </span>
            <select
              value={activeProjectId}
              onChange={(e) => handleSelectProject(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-lg px-3 py-1.5 font-mono focus:outline-none focus:border-current transition-all w-full sm:w-56 cursor-pointer"
            >
              {(Object.values(projects) as VirtualProject[]).map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Language Toggle Button */}
          <button
            onClick={handleToggleLang}
            className="px-2.5 py-2 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 hover:bg-cyan-950/10 text-slate-300 hover:text-cyan-400 transition-all flex items-center justify-center gap-1 cursor-pointer font-mono text-xs font-semibold"
            title={lang === 'en' ? "Переключить на русский" : "Switch to English"}
          >
            <span>{lang === 'en' ? "RU" : "EN"}</span>
          </button>

          <button
            onClick={handleResetWorkspace}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 hover:border-rose-950 hover:bg-rose-950/10 text-slate-500 hover:text-rose-400 transition-all flex items-center justify-center gap-1 cursor-pointer"
            title={lang === 'ru' ? "Сбросить рабочую область" : "Reset Entire Workspace baseline"}
          >
            <Undo2 className="w-4 h-4" />
          </button>
        </div>

      </header>

      {/* Primary Cockpit navigation bar */}
      <nav className="border-b border-slate-900 bg-slate-950 px-6 py-2 flex gap-1 overflow-x-auto scrollbar-none">
        {navItems.map(item => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold font-mono whitespace-nowrap border transition-all cursor-pointer ${
                isActive
                  ? themeCls.btnActive
                  : "text-slate-500 hover:text-slate-300 hover:bg-slate-900/30 border-transparent"
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Main Workspace Frame container */}
      <main className="flex-1 p-6 max-w-7xl w-full mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.15 }}
            className="h-full"
          >
            {activeTab === 'dashboard' && (
              <Dashboard 
                telemetry={telemetry} 
                logs={logs} 
                onResetWorkspace={handleResetWorkspace}
                onToggleModelSelect={handleSelectModel}
                selectedModelId={selectedModelId}
                telegramConfig={telegramConfig}
                onUpdateTelegramConfig={handleUpdateTelegramConfig}
                onTestTelegram={handleTestTelegram}
                currentTheme={currentTheme}
                onSelectTheme={handleSelectTheme}
                memoryPoolEnabled={memoryPoolEnabled}
                onToggleMemoryPool={handleToggleMemoryPool}
                rustFfiApplied={rustFfiApplied}
                onToggleRustFfi={handleToggleRustFfi}
                lang={lang}
              />
            )}

            {activeTab === 'explorer' && (
              <ProjectExplorer 
                project={activeProject}
                onFileUpdate={handleFileUpdate}
                onRunTests={handleRunTests}
                lang={lang}
              />
            )}

            {activeTab === 'aider' && (
              <AiderChat 
                tasks={tasks}
                onTaskCreate={handleTaskCreate}
                selectedModelId={selectedModelId}
                modelConfigs={modelConfigs}
                lang={lang}
              />
            )}

            {activeTab === 'automation' && (
              <AutomationControl 
                isNightMode={isNightModeAutomationRunning}
                onToggleNightMode={handleToggleNightMode}
                tests={activeProject.tests}
                tasks={tasks}
                lang={lang}
              />
            )}

            {activeTab === 'models' && (
              <ModelSelector 
                modelConfigs={modelConfigs}
                selectedModelId={selectedModelId}
                onSelectModel={handleSelectModel}
                offlineFallbackActive={telemetry.offlineFallbackActive}
                lang={lang}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom status diagnostics footer bar */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-3 flex flex-col sm:flex-row items-center justify-between text-[10px] text-slate-600 font-mono gap-2">
        <div className="flex flex-wrap items-center gap-4">
          <span>{lang === 'ru' ? "Активный проект: " : "Active project: "}<b className="text-slate-400">{activeProject.name}</b></span>
          <span className="hidden sm:inline">|</span>
          <span>{lang === 'ru' ? "Движок: " : "Engine: "}<b className="text-slate-400">{selectedModelId}</b></span>
        </div>
        
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> API: {lang === 'ru' ? "Онлайн" : "Online"}
          </span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> {lang === 'ru' ? "Локальный узел: подключен" : "Local node: connected"}
          </span>
          <span>© 2026 Aider GUI Node-Bridge</span>
        </div>
      </footer>

    </div>
  );
}
